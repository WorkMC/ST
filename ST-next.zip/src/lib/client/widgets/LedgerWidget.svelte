<script lang="ts">
    import {ledgerStore} from "$lib/stores";
    import {writable} from "svelte/store";

    const ledger = $derived(ledgerStore || writable({ data: [] }));

    let showToday = $state(true);
    function switchView() {
        showToday = !showToday;
    }
</script>

<button onclick={switchView}>Switch View (Today / All)</button>
{#if showToday}
    <table>
        <thead>
        <tr class="no_interaction">
            <th style="border-right: 1px solid #eee; border-left: 1px solid #eee; padding: 8px;">Timestamp</th>
            <th style="border-right: 1px solid #eee; padding: 8px;">Price</th>
            <th style="border-right: 1px solid #eee; padding: 8px;">Change</th>
            <th style="border-right: 1px solid #eee; padding: 8px;">Volume</th>
            <th style="border-right: 1px solid #eee; padding: 8px;">Cumulative Volume</th>
        </tr>
        </thead>
        <tbody>
        {#if $ledger.data?.length > 0}
            {#each $ledger.data as entry, i (entry.timestamp + '-' + i)}
                <tr>
                    <td style="border-bottom: 1px solid #eee; border-right: 1px solid #eee; padding: 8px;">{new Date(entry.timestamp).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}</td>
                    <td style="border-bottom: 1px solid #eee; border-right: 1px solid #eee; padding: 8px;">{entry.price?.toLocaleString('ko-KR', { style: 'currency', currency: 'KRW' })}</td>
                    <td style="border-bottom: 1px solid #eee; border-right: 1px solid #eee; padding: 8px;"></td>
                    <td style="border-bottom: 1px solid #eee; border-right: 1px solid #eee; padding: 8px;">{entry.volume}</td>
                    <td style="border-bottom: 1px solid #eee; padding: 8px;">{entry.cumulativeVolume}</td>
                </tr>
            {/each}
        {:else}
            <tr class="no_interaction">
                <td colspan="5" style="border-bottom: 1px solid #eee; border-right: 1px solid #eee; border-left: 1px solid #eee; padding: 8px; text-align: center;">No ledger data available</td>
            </tr>
        {/if}
        </tbody>
    </table>
{:else}
    <table>
        <thead>
        <tr class="no_interaction">
            <th style="border-right: 1px solid #eee; border-left: 1px solid #eee; padding: 8px;">Timestamp</th>
            <th style="border-right: 1px solid #eee; padding: 8px;">Change</th>
            <th style="border-right: 1px solid #eee; padding: 8px;">Open</th>
            <th style="border-right: 1px solid #eee; padding: 8px;">High</th>
            <th style="border-right: 1px solid #eee; padding: 8px;">Low</th>
            <th style="border-right: 1px solid #eee; padding: 8px;">Close</th>
            <th style="border-right: 1px solid #eee; padding: 8px;">Volume</th>
            <th style="border-right: 1px solid #eee; padding: 8px;">Volume(￦)</th>
        </tr>
        </thead>
        <tbody>
            <tr class="no_interaction">
                <td colspan="8" style="border-bottom: 1px solid #eee; border-right: 1px solid #eee; border-left: 1px solid #eee; padding: 8px; text-align: center;">No ledger data available</td>
            </tr>
        </tbody>
    </table>
{/if}

<style>
    .no_interaction {
        pointer-events: none;
        user-select: none;
    }

    table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
    }

    thead th {
        position: sticky;
        top: 0;
        z-index: 2;
        background: #fff;
        box-shadow: inset 0 -1px 0 #ccc, inset 0 1px 0 #eee;
    }
</style>