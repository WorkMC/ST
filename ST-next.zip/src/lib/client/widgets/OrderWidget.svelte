<script lang="ts">
    import {order} from "$lib/stores";

    let orderData = $derived(order);

    let response: string = $state('');

    function submit() {
        if ($orderData.type === 'market') {
            $orderData.price = 0; // 시장가 주문의 경우 가격을 0으로 설정
        }

        // 비어있는 필드가 있는지 확인
        if (!$orderData.symbol || ($orderData.action !== 'Create' && !$orderData.orderId) || !$orderData.side || !$orderData.type || !$orderData.quantity) {
            response = 'Please fill in all fields.';
            return;
        }

        const orderDetails = JSON.stringify({
            order_id: $orderData.orderId,
            side: $orderData.side,
            type: $orderData.type,
            price: $orderData.price,
            quantity: $orderData.quantity,
        });



        let method = 'POST';
        if ($orderData.action === 'Modify') {
            method = 'PATCH';
        } else if ($orderData.action === 'Cancel') {
            method = 'DELETE';
        }

        fetch(`/api/v1/order?symbol=${$orderData.symbol}`, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: orderDetails,
        }).then(res => res.json())
            .then(data => {
                response = JSON.stringify(data);
            })
            .catch(err => {
                response = 'Error: ' + err.message;
            });
    }
</script>

{#if response}
    <p>Response: {response}</p>
{/if}
<!--<input type="text" placeholder="Enter the Symbol" bind:value={$orderData.symbol} style="display: block; margin-top: 5px;" />-->
<select bind:value={$orderData.action} style="display: block; margin-top: 5px;">
    <option value="Create">Create</option>
    <option value="Modify">Modify</option>
    <option value="Cancel">Cancel</option>
</select>
{#if $orderData.action !== 'Create'}
    <input type="text" placeholder="Enter the Order ID" bind:value={$orderData.orderId} style="display: block; margin-top: 5px;" />
{/if}
<select bind:value={$orderData.side} style="display: block; margin-top: 5px;">
    <option value="buy">Buy</option>
    <option value="sell">Sell</option>
</select>
<select bind:value={$orderData.type} style="display: block; margin-top: 5px;">
    <option value="limit">Limit</option>
    <option value="market">Market</option>
</select>
{#if $orderData.type === 'limit'}
    <input type="number" placeholder="Enter the Price" bind:value={$orderData.price} style="display: block; margin-top: 5px;" />
{/if}
<input type="number" placeholder="Enter the Quantity" bind:value={$orderData.quantity} style="display: block; margin-top: 5px;" />
<button onclick={submit} style="display: block; margin-top: 10px;">Submit</button>